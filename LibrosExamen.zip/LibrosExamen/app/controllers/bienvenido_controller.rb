class BienvenidoController < ApplicationController
  def index
  end
end
