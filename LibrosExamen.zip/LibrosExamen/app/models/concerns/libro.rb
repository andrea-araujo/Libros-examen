class Libro < ActiveRecord::Base
  validates :titulo, presence: true, uniqueness: true
  validates :autor, presence: true, length: {minimum: 6 }
  #validates :username, format: {with: /regex/}
end

